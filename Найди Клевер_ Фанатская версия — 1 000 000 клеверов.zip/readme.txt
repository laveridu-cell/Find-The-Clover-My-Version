WebEXE Desktop Application
=========================

This application was created with WebEXE at https://webexe.cc.
Order number: 193a0c77c7b6799c3979728ad8c55d94

Getting started
1. Extract the ZIP archive to a folder on your computer.
2. Double-click the .exe file to start the application.

Using the application
Use this application on a compatible Windows computer.
If it does not open, extract the archive again and try restarting it.

Content and permissions
The application content was provided by its creator.
Use and share it only with the permission of the relevant rights holders.

Created with WebEXE - https://webexe.cc
